Narissa Tsuboi 
11/3/2021

Video Inventory Program
Is your solution fully working or not?
Yes. 

How much time did you spend on the assignment? 10 hours. 

Any feedback on the assignment? No. 