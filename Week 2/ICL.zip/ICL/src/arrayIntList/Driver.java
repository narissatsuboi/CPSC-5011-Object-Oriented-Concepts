/*
 * Sheila Oh
 * CPSC 5011, Seattle University
 * This is free and unencumbered software released into the public domain.
 */
package arrayIntList;

/**
 * 
 * @author ohsh
 */
public class Driver {

	/**
	 * Test driver for the {@code ArrayIntList} class
	 * @param args
	 */
	public static void main(String[] args) {
		

	}

}
