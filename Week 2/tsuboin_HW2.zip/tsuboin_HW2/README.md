Narissa Tsuboi
HW2 README Password Vault 

1. Is your solution fully working or not? 
    My solution is fully working. 
2. Do you believe your unit tests to be complete to test the module's contract?
   If not, why not? 
   The unit tests included in the driver show the successful execution of 
   PasswordVaults functions as well as the successful throwing of custom 
   exceptions in the appropriate situations.
   I also performed unit tests on PasswordVault, and the classes I added. 
3. No extra credit was assigned. 
4. I spend about 10-12 hours on this assignment. 
5. No feedback. 